const {sayMyName} = require("my-package")

sayMyName("Brad")
