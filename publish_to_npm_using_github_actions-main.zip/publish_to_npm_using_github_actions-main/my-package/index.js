console.log("Hello from our very own npm package.")

const sayMyName = name => console.log(`Your name is ${name}.`)

module.exports = {sayMyName}
